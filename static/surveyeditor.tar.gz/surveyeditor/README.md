Use **surveyjs Editor** to create or edit JSON for surveyjs library.

##Getting started

Build a survey JSON using [Visual Editor](https://surveyjs.io/Editor/Editor/).

Go to [SurveyJS Editor Website](https://surveyjs.io/Overview/Editor/) to get the instruction for adding survey editor into your page. 

To find our more about the surveyjs library go to the [surveyjs.io site](https://surveyjs.io/Overview/Library/).